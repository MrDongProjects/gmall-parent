create definer = root@`%` view base_category_view as
select `gmall_product`.`base_category3`.`id`   AS `id`,
       `gmall_product`.`base_category1`.`id`   AS `category1_id`,
       `gmall_product`.`base_category1`.`name` AS `category1_name`,
       `gmall_product`.`base_category2`.`id`   AS `category2_id`,
       `gmall_product`.`base_category2`.`name` AS `category2_name`,
       `gmall_product`.`base_category3`.`id`   AS `category3_id`,
       `gmall_product`.`base_category3`.`name` AS `category3_name`
from ((`gmall_product`.`base_category1` join `gmall_product`.`base_category2` on ((
        `gmall_product`.`base_category1`.`id` = `gmall_product`.`base_category2`.`category1_id`)))
         join `gmall_product`.`base_category3`
              on ((`gmall_product`.`base_category2`.`id` = `gmall_product`.`base_category3`.`category2_id`)));

-- comment on column base_category_view.id not supported: 编号

-- comment on column base_category_view.category1_id not supported: 编号

-- comment on column base_category_view.category1_name not supported: 分类名称

-- comment on column base_category_view.category2_id not supported: 编号

-- comment on column base_category_view.category2_name not supported: 二级分类名称

-- comment on column base_category_view.category3_id not supported: 编号

-- comment on column base_category_view.category3_name not supported: 三级分类名称

